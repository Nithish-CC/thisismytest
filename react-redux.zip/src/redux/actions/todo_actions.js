import { Todo } from "../types/redux-types";
import axios from "axios";

export const TodoCreate = (values) => async (dispatch) => {
	try {
		const { data: dataValues } = await axios.get("https://fakestoreapi.com/products");
		console.log(dataValues);
		dispatch({
			type: Todo.SET_TODO_CREATE,
			payload: dataValues,
		});
	} catch (error) {}
};

export const TodoDelete = (values) => {
	console.log(values);
	return {
		type: Todo.SET_TODO_DELETE,
		payload: values,
	};
};
